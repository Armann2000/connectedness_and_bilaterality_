#include </home/arasatry/cpp/graph/run_graph.h>

int main(int argc, char* argv[]){
    cmdl cmd(argc, argv);
    run_graph a;
    return 0;
}
